<?php
/**
 * Captcha field.
 *
 * @package    WPFormsCaptcha
 * @author     WPForms
 * @since      1.0.0
 * @license    GPL-2.0+
 * @copyright  Copyright (c) 2016, WPForms LLC
 */
class WPForms_Captcha_Field extends WPForms_Field {

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function init() {

		// Define field type information
		$this->name  = __( 'Captcha', 'wpforms_captcha' );
		$this->type  = 'captcha';
		$this->icon  = 'fa-question-circle';
		$this->order = 30;
		$this->group = 'fancy';
		$this->math  = apply_filters( 'wpforms_math_captcha', array(
			'min' => 1,
			'max' => 15,
			'cal' => array( '+', '*' ),
		) );
		$this->qs    = array(
			1 => array(
				'question' => __( 'What is the fourth letter of the alphabet?', 'wpforms_captcha' ),
				'answer'   => __( 'D', 'wpforms_captcha' ),
			),
			2 => array(
				'question' => '',
				'answer'   => '',
			),
		);

		// Define additional field properties.
		add_filter( 'wpforms_field_properties_captcha' , array( $this, 'field_properties' ), 5, 3 );

		// Set field to default to required.
		add_filter( 'wpforms_field_new_required', array( $this, 'default_required' ), 10, 2 );

		// Remove the field from saved data.
		add_filter( 'wpforms_process_after_filter', array( $this, 'remove_field' ), 10, 3 );

		// Load site frontend assets.
		add_action( 'wpforms_wp_footer', array( $this, 'frontend_assets' ) );

		// Load form builder assets.
		add_action( 'wpforms_builder_enqueues', array( $this, 'builder_assets' ) );
	}

	/**
	 * Define additional field properties.
	 *
	 * @since 1.3.8
	 * @param array $properties
	 * @param array $field
	 * @param array $form_data
	 * @return array
	 */
	public function field_properties( $properties, $field, $form_data ) {

		$field_id = absint( $field['id'] );
		$format   = ! empty( $field['format'] ) ? $field['format'] : 'math';

		// Input Primary: adjust name.
		$properties['inputs']['primary']['attr']['name'] = "wpforms[fields][{$field_id}][a]";

		// Input Primary: adjust class.
		$properties['inputs']['primary']['class'][] = 'a';

		// Input Primary: type dat attr.
		$properties['inputs']['primary']['data']['rule-wpf-captcha'] = $format;

		return $properties;
	}

	/**
	 * Field should default to being required.
	 *
	 * @since 1.0.0
	 * @param bool $required
	 * @param array $field
	 * @return bool
	 */
	public function default_required( $required, $field ) {

		if ( 'captcha' === $field['type'] ) {
			return true;
		}
		return $required;
	}

	/**
	 * Don't store captcha fields since it's for validation only.
	 *
	 * @since 1.0.0
	 * @param array $fields
	 * @param array $entry
	 * @param array $form_data
	 * @return array
	 */
	public function remove_field( $fields, $entry, $form_data ) {

		foreach ( $fields as $id => $field ) {
			// Remove captchas from saved data.
			if ( 'captcha' === $field['type'] ) {
				unset( $fields[ $id ] );
			}
		}
		return $fields;
	}

	/**
	 * Enqueue assets in the frontend.
	 *
	 * @since 1.0.0
	 * @param array $forms
	 */
	public function frontend_assets( $forms ) {

		if ( ! wpforms_has_field_type( 'captcha', $forms, true ) && ! wpforms()->frontend->assets_global() ) {
			return;
		}

		// JS.
		wp_enqueue_script(
			'wpforms-captcha',
			plugin_dir_url( __FILE__ ) . 'assets/js/wpforms-captcha.js',
			array( 'jquery' ),
			WPFORMS_CAPTCHA_VERSION,
			true
		);
		$vars = array(
			'max' => $this->math['max'],
			'min' => $this->math['min'],
			'cal' => $this->math['cal'],
		);
		wp_localize_script( 'wpforms-captcha', '_wpforms_captcha', $vars );
	}

	/**
	 * Enqueue assets for the builder.
	 *
	 * @since 1.0.0
	 */
	public function builder_assets() {

		// CSS.
		wp_enqueue_style(
			'wpforms-bhilder-custom-captcha',
			plugin_dir_url( __FILE__ ) . 'assets/css/admin-builder-captcha.css',
			array(),
			WPFORMS_CAPTCHA_VERSION
		);

		// JS.
		wp_enqueue_script(
			'wpforms-builder-custom-captcha',
			plugin_dir_url( __FILE__ ) . 'assets/js/admin-builder-captcha.js',
			array( 'jquery' ),
			WPFORMS_CAPTCHA_VERSION,
			false
		);
	}

	/**
	 * Field options panel inside the builder.
	 *
	 * @since 1.0.0
	 * @param array $field
	 */
	public function field_options( $field ) {

		$format = ! empty( $field['format'] ) ? esc_attr( $field['format'] ) : 'math';

		// Always required.
		$args = array(
			'type'  => 'hidden',
			'slug'  => 'required',
			'value' => '1',
		);
		$this->field_element( 'text', $field, $args );

		// -------------------------------------------------------------------//
		// Basic field options.
		// -------------------------------------------------------------------//

		// Options open markup.
		$args = array(
			'markup' => 'open',
		);
		$this->field_option( 'basic-options', $field, $args );

		// Label.
		$this->field_option( 'label', $field );

		// Format.
		$lbl = $this->field_element(
			'label',
			$field,
			array(
				'slug'    => 'format',
				'value'   => __( 'Type', 'wpforms_math_captcha' ),
				'tooltip' => __( 'Select type of captcha to use.', 'wpforms_math_captcha' ),
			),
			false
		);
		$fld = $this->field_element(
			'select',
			$field,
			array(
				'slug'    => 'format',
				'value'   => $format,
				'options' => array(
					'math' => __( 'Math', 'wpforms_captcha' ),
					'qa'   => __( 'Question and Answer', 'wpforms_captcha' ),
				),
			),
			false
		);
		$args = array(
			'slug'    => 'format',
			'content' => $lbl . $fld,
		);
		$this->field_element( 'row', $field, $args );

		// Questions.
		$lbl = $this->field_element(
			'label',
			$field,
			array(
				'slug'    => 'questions',
				'value'   => __( 'Questions and Answers', 'wpforms_captcha' ),
				'tooltip' => __( 'Add questions to ask the user. Questions are randomly selected.', 'wpforms_captcha' ),
			),
			false
		);
		$qs  = ! empty( $field['questions'] ) ? $field['questions'] : $this->qs;
		$fld = sprintf( '<ul data-next-id="%s" data-field-id="%d" data-field-type="%s">', max( array_keys( $qs ) ) + 1, $field['id'], $this->type );
		foreach ( $qs as $key => $value ) {
			$fld .= '<li data-key="' . absint( $key ) . '">';
				$fld .= sprintf( '<input type="text" name="fields[%s][questions][%s][question]" value="%s" class="question" placeholder="%s">', $field['id'], $key, esc_attr( $value['question'] ), __( 'Question', 'wpforms_captcha' ) );
				$fld .= '<a class="add" href="#"><i class="fa fa-plus-circle"></i></a><a class="remove" href="#"><i class="fa fa-minus-circle"></i></a>';
				$fld .= sprintf( '<input type="text" name="fields[%s][questions][%s][answer]" value="%s" class="answer" placeholder="%s">', $field['id'], $key, esc_attr( $value['answer'] ), __( 'Answer', 'wpforms_captcha' ) );
			$fld .= '</li>';
		}
		$fld .= '</ul>';
		$args = array(
			'slug'    => 'questions',
			'content' => $lbl . $fld,
			'class'   => 'math' === $format ? 'wpforms-hidden' : '',
		);
		$this->field_element( 'row', $field, $args );

		// Description.
		$this->field_option( 'description', $field );

		// Options close markup.
		$args = array(
			'markup' => 'close',
		);
		$this->field_option( 'basic-options', $field, $args );

		// -------------------------------------------------------------------//
		// Advanced field options.
		// -------------------------------------------------------------------//

		// Options open markup.
		$args = array(
			'markup' => 'open',
		);
		$this->field_option( 'advanced-options', $field, $args );

		// Size.
		$args = array(
			'class' => 'math' === $format ? 'wpforms-hidden' : '',
		);
		$this->field_option( 'size', $field, $args );

		// Placeholder.
		$this->field_option( 'placeholder', $field );

		// Hide Label.
		$this->field_option( 'label_hide', $field );

		// Custom CSS classes.
		$this->field_option( 'css', $field );

		// Options close markup.
		$args = array(
			'markup' => 'close',
		);
		$this->field_option( 'advanced-options', $field, $args );
	}

	/**
	 * Field preview inside the builder.
	 *
	 * @since 1.0.0
	 * @param array $field
	 */
	public function field_preview( $field ) {

		// Define data.
		$placeholder = ! empty( $field['placeholder'] ) ? esc_attr( $field['placeholder'] ) : '';
		$format      = ! empty( $field['format'] ) ? $field['format'] : 'math';
		$num1        = mt_rand( $this->math['min'], $this->math['max'] );
		$num2        = mt_rand( $this->math['min'], $this->math['max'] );
		$cal         = $this->math['cal'][ mt_rand( 0, count( $this->math['cal'] ) - 1) ];
		$qs          = ! empty( $field['questions'] ) ? $field['questions'] : $this->qs;

		// Label.
		$this->field_preview_option( 'label', $field );
		?>

		<div class="format-selected-<?php echo $format; ?> format-selected">

			<span class="wpforms-equation"><?php echo "$num1 $cal $num2 = "; ?></span>

			<p class="wpforms-question"><?php echo $qs[1]['question']; ?></p>

			<input type="text" placeholder="<?php echo $placeholder; ?>" class="primary-input" disabled>

		</div>

		<?php
		// Description.
		$this->field_preview_option( 'description', $field );
	}

	/**
	 * Field display on the form front-end.
	 *
	 * @since 1.0.0
	 * @param array $field
	 * @param array $deprecated
	 * @param array $form_data
	 */
	public function field_display( $field, $deprecated, $form_data ) {

		// Define data.
		$field_id = absint( $field['id'] );
		$primary  = $field['properties']['inputs']['primary'];
		$format   = $form_data['fields'][ $field_id ]['format'];

		if ( 'math' === $format ) {
			// Math Captcha.
			?>
			<div class="wpforms-captcha-math">
				<span class="wpforms-captcha-equation">
					<span class="n1"></span>
					<span class="cal"></span>
					<span class="n2"></span>
					<span class="e">=</span>
				</span>
				<?php
				printf( '<input type="text" %s %s>',
					wpforms_html_attributes( $primary['id'], $primary['class'], $primary['data'], $primary['attr'] ),
					$primary['required']
				);
				?>
				<input type="hidden" name="wpforms[fields][<?php echo $field_id; ?>][cal]" class="cal">
				<input type="hidden" name="wpforms[fields][<?php echo $field_id; ?>][n2]" class="n2">
				<input type="hidden" name="wpforms[fields][<?php echo $field_id; ?>][n1]" class="n1">
			</div>
			<?php
		} else {
			// Question and Answer captcha.
			$qid = $this->random_question( $field, $form_data );
			$q   = esc_html( $form_data['fields'][ $field_id ]['questions'][ $qid ]['question'] );
			$a   = esc_attr( $form_data['fields'][ $field_id ]['questions'][ $qid ]['answer'] );
			?>
			<p class="wpforms-captcha-question"><?php echo $q; ?></p>
			<?php
				$primary['data']['a'] = $a;
				printf( '<input type="text" %s %s>',
					wpforms_html_attributes( $primary['id'], $primary['class'], $primary['data'], $primary['attr'] ),
					$primary['required']
				);
			?>
			<input type="hidden" name="wpforms[fields][<?php echo $field_id; ?>][q]" value="<?php echo $qid; ?>">
			<?php
		} // End if().
	}

	/**
	 * Select a random question.
	 *
	 * @param array $field
	 * @param array $form_data
	 * @return int
	 */
	public function random_question( $field, $form_data ) {

		if ( empty( $form_data['fields'][ $field['id'] ]['questions'] ) ) {
			return false;
		}

		$index = array_rand( $form_data['fields'][ $field['id'] ]['questions'] );

		if ( empty( $form_data['fields'][ $field['id'] ]['questions'][ $index ]['question'] ) || empty( $form_data['fields'][ $field['id'] ]['questions'][ $index ]['answer'] ) ) {
			$index = $this->random_question( $field, $form_data );
		}

		return $index;
	}

	/**
	 * Validates field on form submit.
	 *
	 * @since 1.0.0
	 * @param int $field_id
	 * @param array $field_submit
	 * @param array $form_data
	 */
	public function validate( $field_id, $field_submit, $form_data ) {

		// Math captch.
		if ( 'math' === $form_data['fields'][ $field_id ]['format'] ) {

			// All calculation fields are required
			if (    empty( $field_submit['a']   )
				 || empty( $field_submit['n1']  )
				 || empty( $field_submit['cal'] )
				 || empty( $field_submit['n2']  )
			) {
				wpforms()->process->errors[ $form_data['id'] ][ $field_id ] = apply_filters( 'wpforms_required_label', __( 'This field is required', 'wpforms_captcha' ) );
				return;
			}

			$n1  = $field_submit['n1'];
			$cal = $field_submit['cal'];
			$n2  = $field_submit['n2'];
			$a   = trim( $field_submit['a'] );
			$x   = false;

			switch ( $cal ) {
				case '+' :
					$x = ( $n1 + $n2 );
					break;
				case '-' :
					$x = ( $n1 - $n2 );
					break;
				case '*' :
					$x = ( $n1 * $n2 );
					break;
			}

			if ( $x != $a ) {
				wpforms()->process->errors[ $form_data['id'] ][ $field_id ] = __( 'Incorrect answer', 'wpforms_captcha' );
				return;
			}
		}

		if ( 'qa' === $form_data['fields'][ $field_id ]['format'] ) {

			// All fields are required
			if ( empty( $field_submit['q'] ) || empty( $field_submit['a'] ) ) {
				wpforms()->process->errors[ $form_data['id'] ][ $field_id ] = apply_filters( 'wpforms_required_label', __( 'This field is required', 'wpforms_captcha' ) );
				return;
			}

			if ( trim( strtolower( $field_submit['a'] ) ) != trim( strtolower( $form_data['fields'][ $field_id ]['questions'][ $field_submit['q'] ]['answer'] ) ) ) {
				wpforms()->process->errors[ $form_data['id'] ][ $field_id ] = __( 'Incorrect answer', 'wpforms_captcha' );
				return;
			}
		}
	}
}
new WPForms_Captcha_Field;
