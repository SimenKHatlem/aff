;(function($) {

	var WPFormsCaptcha = {

		/**
		 * Start the engine.
		 *
		 * @since 1.0.0
		 */
		init: function() {

			// Document ready
			$(document).ready(WPFormsCaptcha.ready);

			// Binds/Actions
			WPFormsCaptcha.bindUIActions();
		},

		/**
		 * Document ready.
		 *
		 * @since 1.0.0
		 */
		ready: function() {

			// Populate random equations for math captcha
			$('.wpforms-captcha-equation').each(function(index, el) {

				var $wpf_captcha = $(this).parent(),
					wpf_cal = _wpforms_captcha.cal[Math.floor(Math.random() * _wpforms_captcha.cal.length)];
					wpf_n1  = WPFormsCaptcha.randomNumber(_wpforms_captcha.min, _wpforms_captcha.max ),
					wpf_n2  = WPFormsCaptcha.randomNumber(_wpforms_captcha.min, _wpforms_captcha.max ),

				$wpf_captcha.find('span.n1').text(wpf_n1)
				$wpf_captcha.find('input.n1').val(wpf_n1);
				$wpf_captcha.find('span.n2').text(wpf_n2);
				$wpf_captcha.find('input.n2').val(wpf_n2);
				$wpf_captcha.find('span.cal').text(wpf_cal);
				$wpf_captcha.find('input.cal').val(wpf_cal);
				$wpf_captcha.find('input.a').attr({
					'data-cal': wpf_cal,
					'data-n1': wpf_n1,
					'data-n2': wpf_n2
				})
			});

			// Init custom captcha validation
			WPFormsCaptcha.loadValidation();
		},

		/**
		 * Custom captcha validation.
		 *
		 * @since 1.0.0
		 */
		loadValidation: function() {

			// Only load if jQuery validation library exists
			if (typeof $.fn.validate !== 'undefined') {

				$.validator.addMethod("wpf-captcha", function(value, element, param) {
					var $ele = $(element);
					if ( 'math' === param ) {
						// Math captcha
						var n1  = Number($ele.attr('data-n1')),
							n2  = Number($ele.attr('data-n2')),
							cal = $ele.attr('data-cal'),
							a   = Number(value);
							res = false;

						switch ( cal ) {
							case '-' :
								res = (n1-n2);
								break;
							case '+' :
								res = (n1+n2);
								break;
							case '*' :
								res = (n1*n2);
								break;
						}
					} else {
						// Question answer captcha
						var a   = $.trim(value.toString().toLowerCase()),
							res = $.trim($ele.attr('data-a').toString().toLowerCase());
					}
					return this.optional(element) || a === res;
				}, $.validator.format("Incorrect answer"));
			}
		},

		/**
		 * Element bindings.
		 *
		 * @since 1.0.0
		 */
		bindUIActions: function() {

			// OptinMonster: initialize again after OM is finished.
			// This is to accomodate moving the form in the DOM.
			$(document).on('OptinMonsterAfterInject', function(event) {
				WPFormsCaptcha.ready();
			});
		},

		/**
		 * Generate random whole number.
		 *
		 * @since 1.0.0
		 */
		randomNumber: function(min, max) {
			return Math.floor(Math.random() * (Number(max) - Number(min) + 1)) + Number(min);
		}
	}

	WPFormsCaptcha.init();

	window.wpforms_captcha = WPFormsCaptcha;
})(jQuery);
