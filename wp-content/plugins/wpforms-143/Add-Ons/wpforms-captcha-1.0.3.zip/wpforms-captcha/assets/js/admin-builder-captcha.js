;(function($) {

	var WPFormsCaptcha = {

		/**
		 * Start the engine.
		 *
		 * @since 1.0.0
		 */
		init: function() {

			WPFormsCaptcha.bindUIActions();

			$(document).ready(WPFormsCaptcha.ready);
		},

		/**
		 * Document ready.
		 *
		 * @since 1.0.0
		 */
		ready: function() {

		},

		/**
		 * Element bindings.
		 *
		 * @since 1.0.0
		 */
		bindUIActions: function() {

			// Type (format) toggle
			$(document).on('change', '.wpforms-field-option-captcha .wpforms-field-option-row-format select', function(e) {
				var $this = $(this),
					value = $this.val(),
					id    = $this.parent().data('field-id');
				if ( value === 'math') {
					$('#wpforms-field-option-row-'+id+'-questions').hide();
					$('#wpforms-field-option-row-'+id+'-size').hide();
				} else {
					$('#wpforms-field-option-row-'+id+'-questions').show();
					$('#wpforms-field-option-row-'+id+'-size').show();
				}
			});

			// Captcha question add new
			$(document).on('click', '.wpforms-field-option-row-questions .add', function(e) {

				e.preventDefault();

				var $this     = $(this),
					$parent   = $this.parent(),
					fieldID   = $this.closest('.wpforms-field-option-row-questions').data('field-id'),
					id        = $parent.parent().attr('data-next-id'),
					question  = $parent.clone().insertAfter($parent);

				question.attr('data-key', id);
				question.find('input.question').val('').attr('name', 'fields['+fieldID+'][questions]['+id+'][question]');
				question.find('input.answer').val('').attr('name', 'fields['+fieldID+'][questions]['+id+'][answer]');
				id++;
				$parent.parent().attr('data-next-id', id);
			});

			// Captcha question delete
			$(document).on('click', '.wpforms-field-option-row-questions .remove', function(e) {

				e.preventDefault();

				var $this = $(this),
					$list = $this.parent().parent(),
					total = $list.find('li').length;

				if (total == '1') {
					$.alert({
						title: false,
						content: wpforms_builder.error_choice,
						icon: 'fa fa-exclamation-circle',
						type: 'orange',
						buttons: {
							confirm: {
								text: wpforms_builder.ok,
								btnClass: 'btn-confirm',
								keys: ['enter']
							}
						}
					});
				} else {
					$this.parent().remove();
				}
			});

			// Captch questions sample question
			$(document).on('input', '.wpforms-field-option-row-questions li:first-of-type .question', function(e) {
				var fieldID = $(this).parent().parent().data('field-id');
				$('#wpforms-field-'+fieldID).find('.wpforms-question').text($(this).val());
			});
		}
	}

	WPFormsCaptcha.init();
})(jQuery);
