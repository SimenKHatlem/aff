Change Log
All notable changes to this project will be documented in this file, formatted via [this recommendation](http://keepachangelog.com/).

## [1.0.4] - 2017-08-21
### Changed
- Template uses new `core` property so it displays with other core templates

## [1.0.3] - 2017-03-09
### Added
- Improved integration for storing The Events Calendar post meta

## [1.0.2] - 2017-02-22
### Fixed
- Capitalized letters not being allowed in custom post meta keys

## [1.0.1] - 2017-01-17
### Fixed
- Possible error if custom meta fields were setup but incomplete

## [1.0.0] - 2016-10-5
- Initial release
